$* parent10/parent9/parent8/parent7/parent6/parent5/parent4/parent3/parent2/parent1
